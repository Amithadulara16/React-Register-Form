import React, { useState } from 'react';

export default function Login() {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    address: '',
    gender: '',
    birthday: '',
    schoolName: '',
    universityName: '',
    degreeName: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Here you can add logic to send formData to a server or API
  };        
  return (
    <div className="min-h-screen flex items-center justify-center bg-green-400 p-4">
      <div className="max-w-md w-full bg-sky-100 rounded-lg shadow-md p-8">
        <h2 className="text-2xl font-bold mb-6 text-center">Register Form</h2>
        <form onSubmit={handleSubmit} className="space-y-4">

          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
            <input type="text" name="name" id="name" required
              value={formData.name} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="age" className="block text-sm font-medium text-gray-700">Age</label>
            <input type="number" name="age" id="age" required min="0"
              value={formData.age} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
            <input type="text" name="address" id="address" required
              value={formData.address} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="gender" className="block text-sm font-medium text-gray-700">Gender</label>
            <select name="gender" id="gender" required
              value={formData.gender} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600">
              <option value="">Select gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label htmlFor="birthday" className="block text-sm font-medium text-gray-700">Birthday</label>
            <input type="date" name="birthday" id="birthday" required
              value={formData.birthday} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="schoolName" className="block text-sm font-medium text-gray-700">School Name</label>
            <input type="text" name="schoolName" id="schoolName" required
              value={formData.schoolName} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="universityName" className="block text-sm font-medium text-gray-700">University Name</label>
            <input type="text" name="universityName" id="universityName" required
              value={formData.universityName} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <div>
            <label htmlFor="degreeName" className="block text-sm font-medium text-gray-700">Degree Name</label>
            <input type="text" name="degreeName" id="degreeName" required
              value={formData.degreeName} onChange={handleChange}
              className="mt-1 block w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600" />
          </div>

          <button type="submit" className="text-white bg-gradient-to-br from-pink-500 to-orange-400 hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-pink-200 dark:focus:ring-pink-800 font-medium rounded-lg text-sm px-5 py-2.5 text-center me-2 mb-2">
            Submit
          </button>
        </form>
      </div>
    </div>
  );
}
